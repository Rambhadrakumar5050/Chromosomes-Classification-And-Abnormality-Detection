"""
Phase 3 — Training Loop
Trains each model independently with same settings for fair comparison.
Supports: early stopping, LR scheduling, checkpoint saving, live loss curves.

Usage:
    python 03_train.py --model resnet50 --epochs 60
    python 03_train.py --model efficientnet --epochs 60
    python 03_train.py --model vgg16 --epochs 60
    python 03_train.py --model varifocalnet --epochs 60
"""

import os
import json
import time
import argparse
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

from _01_eda_preprocessing import build_dataloaders   # adjust import if needed
from _02_models import get_model

# rename imports to match filenames without leading digit if needed
# from eda_preprocessing import build_dataloaders
# from models import get_model


# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────
CFG = {
    "split_root":    "dataset_split",
    "num_classes":   24,          # 22 + X + Y
    "img_size":      224,
    "batch_size":    32,
    "num_workers":   4,
    "epochs":        60,
    "lr":            1e-4,        # initial LR
    "weight_decay":  1e-4,
    "patience":      10,          # early stopping patience
    "checkpoint_dir": "checkpoints",
    "seed":          42,
}

# Label-smoothing cross-entropy helps generalization on medical data
LABEL_SMOOTHING = 0.1


# ─────────────────────────────────────────────
# LOSS
# ─────────────────────────────────────────────
def get_loss_fn(num_classes: int):
    """
    Label-smoothing cross-entropy loss.
    Prevents overconfident predictions — important for similar-looking
    chromosome classes (e.g. 6 vs X, 14 vs 15).
    """
    return nn.CrossEntropyLoss(label_smoothing=LABEL_SMOOTHING)


# ─────────────────────────────────────────────
# TRAINING ONE EPOCH
# ─────────────────────────────────────────────
def train_epoch(model, loader, optimizer, loss_fn, device, scaler=None):
    model.train()
    total_loss, correct, total = 0.0, 0, 0

    for images, labels in loader:
        images, labels = images.to(device), labels.to(device)
        optimizer.zero_grad()

        if scaler is not None:   # mixed precision
            with torch.cuda.amp.autocast():
                logits = model(images)
                loss   = loss_fn(logits, labels)
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            scaler.step(optimizer)
            scaler.update()
        else:
            logits = model(images)
            loss   = loss_fn(logits, labels)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()

        total_loss += loss.item() * images.size(0)
        preds       = logits.argmax(dim=1)
        correct    += (preds == labels).sum().item()
        total      += images.size(0)

    return total_loss / total, correct / total


# ─────────────────────────────────────────────
# VALIDATION ONE EPOCH
# ─────────────────────────────────────────────
@torch.no_grad()
def eval_epoch(model, loader, loss_fn, device):
    model.eval()
    total_loss, correct, total = 0.0, 0, 0

    for images, labels in loader:
        images, labels = images.to(device), labels.to(device)
        logits         = model(images)
        loss           = loss_fn(logits, labels)

        total_loss += loss.item() * images.size(0)
        preds       = logits.argmax(dim=1)
        correct    += (preds == labels).sum().item()
        total      += images.size(0)

    return total_loss / total, correct / total


# ─────────────────────────────────────────────
# EARLY STOPPING
# ─────────────────────────────────────────────
class EarlyStopping:
    def __init__(self, patience: int = 10, min_delta: float = 1e-4):
        self.patience   = patience
        self.min_delta  = min_delta
        self.best_score = None
        self.counter    = 0
        self.stop       = False

    def step(self, val_loss: float) -> bool:
        score = -val_loss
        if self.best_score is None:
            self.best_score = score
        elif score < self.best_score + self.min_delta:
            self.counter += 1
            if self.counter >= self.patience:
                self.stop = True
        else:
            self.best_score = score
            self.counter    = 0
        return self.stop


# ─────────────────────────────────────────────
# CHECKPOINT UTILS
# ─────────────────────────────────────────────
def save_checkpoint(model, optimizer, epoch, val_acc, model_name, ckpt_dir):
    Path(ckpt_dir).mkdir(parents=True, exist_ok=True)
    path = Path(ckpt_dir) / f"{model_name}_best.pth"
    torch.save({
        "epoch":             epoch,
        "model_state_dict":  model.state_dict(),
        "optimizer_state":   optimizer.state_dict(),
        "val_acc":           val_acc,
    }, path)
    return str(path)


# ─────────────────────────────────────────────
# TRAINING HISTORY PLOT
# ─────────────────────────────────────────────
def plot_history(history: dict, model_name: str):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))

    ax1.plot(history["train_loss"], label="Train loss")
    ax1.plot(history["val_loss"],   label="Val loss")
    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("Loss")
    ax1.set_title(f"{model_name} — Loss curve")
    ax1.legend()
    ax1.grid(alpha=0.3)

    ax2.plot(history["train_acc"], label="Train acc")
    ax2.plot(history["val_acc"],   label="Val acc")
    ax2.set_xlabel("Epoch")
    ax2.set_ylabel("Accuracy")
    ax2.set_title(f"{model_name} — Accuracy curve")
    ax2.legend()
    ax2.grid(alpha=0.3)

    plt.tight_layout()
    plt.savefig(f"history_{model_name}.png", dpi=120)
    plt.close()
    print(f"  Saved → history_{model_name}.png")


# ─────────────────────────────────────────────
# TWO-PHASE TRAINING STRATEGY
# ─────────────────────────────────────────────
def train_model(model_name: str,
                cfg: dict = CFG,
                two_phase: bool = True):
    """
    Full training pipeline for one model.

    Phase A (5 epochs): Freeze backbone, train only head with lr=1e-3.
    Phase B (remaining): Unfreeze all, fine-tune with lr=1e-4.

    This is the standard transfer learning recipe and prevents the
    pretrained weights from being destroyed in the first few epochs.
    """
    torch.manual_seed(cfg["seed"])
    device  = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    use_amp = device.type == "cuda"   # mixed precision only on GPU
    print(f"\n  Device: {device}  ·  AMP: {use_amp}")

    # ── Data ──────────────────────────────────
    loaders, class_names = build_dataloaders(
        cfg["split_root"],
        img_size    = cfg["img_size"],
        batch_size  = cfg["batch_size"],
        num_workers = cfg["num_workers"],
    )
    cfg["num_classes"] = len(class_names)
    print(f"  Classes ({len(class_names)}): {class_names}")

    # ── Model ─────────────────────────────────
    model   = get_model(model_name, cfg["num_classes"]).to(device)
    loss_fn = get_loss_fn(cfg["num_classes"])
    scaler  = torch.cuda.amp.GradScaler() if use_amp else None
    es      = EarlyStopping(patience=cfg["patience"])

    history   = {"train_loss": [], "val_loss": [],
                 "train_acc":  [], "val_acc":  []}
    best_acc  = 0.0
    best_path = None

    # ── Phase A: head-only warmup ─────────────
    if two_phase:
        print("\n  ── Phase A: head warmup (5 epochs, backbone frozen) ──")
        for param in model.parameters():
            param.requires_grad = False
        # Unfreeze classifier head
        for name, module in model.named_children():
            if name in {"fc", "classifier", "head"}:
                for param in module.parameters():
                    param.requires_grad = True

        optimizer = optim.Adam(
            filter(lambda p: p.requires_grad, model.parameters()), lr=1e-3
        )
        for epoch in range(5):
            tr_loss, tr_acc = train_epoch(model, loaders["train"],
                                          optimizer, loss_fn, device, scaler)
            vl_loss, vl_acc = eval_epoch(model, loaders["val"], loss_fn, device)
            print(f"    Warmup {epoch+1:02d}  "
                  f"train_loss={tr_loss:.4f}  train_acc={tr_acc:.4f}  "
                  f"val_acc={vl_acc:.4f}")

    # ── Phase B: full fine-tune ───────────────
    print("\n  ── Phase B: full fine-tune ──")
    for param in model.parameters():
        param.requires_grad = True

    optimizer = optim.AdamW(model.parameters(),
                            lr=cfg["lr"],
                            weight_decay=cfg["weight_decay"])
    scheduler = CosineAnnealingLR(optimizer,
                                  T_max=cfg["epochs"],
                                  eta_min=cfg["lr"] * 0.01)

    for epoch in range(1, cfg["epochs"] + 1):
        t0 = time.time()

        tr_loss, tr_acc = train_epoch(model, loaders["train"],
                                      optimizer, loss_fn, device, scaler)
        vl_loss, vl_acc = eval_epoch(model, loaders["val"], loss_fn, device)
        scheduler.step()

        history["train_loss"].append(tr_loss)
        history["val_loss"].append(vl_loss)
        history["train_acc"].append(tr_acc)
        history["val_acc"].append(vl_acc)

        elapsed = time.time() - t0
        print(f"    Epoch {epoch:03d}/{cfg['epochs']}  "
              f"tr_loss={tr_loss:.4f}  tr_acc={tr_acc:.4f}  "
              f"vl_loss={vl_loss:.4f}  vl_acc={vl_acc:.4f}  "
              f"lr={scheduler.get_last_lr()[0]:.2e}  "
              f"({elapsed:.1f}s)")

        # Save best
        if vl_acc > best_acc:
            best_acc  = vl_acc
            best_path = save_checkpoint(model, optimizer, epoch, vl_acc,
                                        model_name, cfg["checkpoint_dir"])
            print(f"    ✓  New best val_acc={best_acc:.4f} — saved checkpoint")

        # Early stop
        if es.step(vl_loss):
            print(f"    ⏹  Early stop at epoch {epoch} (patience={cfg['patience']})")
            break

    # ── Results ───────────────────────────────
    print(f"\n  [{model_name}]  Best val accuracy: {best_acc:.4f}")
    plot_history(history, model_name)

    # Save history to JSON for comparison later
    hist_path = f"history_{model_name}.json"
    with open(hist_path, "w") as f:
        json.dump({"model": model_name, "best_val_acc": best_acc,
                   "history": history}, f, indent=2)

    return best_acc, best_path, history


# ─────────────────────────────────────────────
# TRAIN ALL MODELS — sequential
# ─────────────────────────────────────────────
def train_all_models(cfg: dict = CFG):
    """
    Train all 4 individual models one by one.
    Results saved in checkpoints/ and history_*.json files.
    Run ensemble separately in 04_evaluate.py after this.
    """
    models_to_train = ["resnet50", "efficientnet", "vgg16", "varifocalnet"]
    results         = {}

    for name in models_to_train:
        print(f"\n{'='*55}")
        print(f"  TRAINING:  {name.upper()}")
        print(f"{'='*55}")
        best_acc, ckpt_path, history = train_model(name, cfg)
        results[name] = {"best_val_acc": best_acc, "checkpoint": ckpt_path}

    print(f"\n{'='*55}")
    print("  TRAINING SUMMARY")
    print(f"{'='*55}")
    for name, res in results.items():
        print(f"  {name:<20}  val_acc = {res['best_val_acc']:.4f}")

    with open("training_results.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\n  Saved → training_results.json")
    print("  ✓  All models trained. Proceed to 04_evaluate.py")

    return results


# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model",  type=str, default="all",
                        choices=["all", "resnet50", "efficientnet",
                                 "vgg16", "varifocalnet"])
    parser.add_argument("--epochs", type=int, default=CFG["epochs"])
    args = parser.parse_args()

    CFG["epochs"] = args.epochs

    if args.model == "all":
        train_all_models(CFG)
    else:
        train_model(args.model, CFG)
