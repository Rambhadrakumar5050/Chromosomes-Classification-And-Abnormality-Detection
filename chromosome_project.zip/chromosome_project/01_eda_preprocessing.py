"""
Phase 1 & 2 — EDA + Preprocessing Pipeline
Chromosome Karyotyping Project
Run this first to understand your dataset before any training.
"""

import os
import cv2
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from collections import Counter
from pathlib import Path
import shutil
import random
import albumentations as A
from albumentations.pytorch import ToTensorV2
from torch.utils.data import Dataset, DataLoader
import torch

# ─────────────────────────────────────────────
# CONFIG — change DATASET_ROOT to your folder
# ─────────────────────────────────────────────
DATASET_ROOT = "path/to/single_chromosomes_object"   # individual crops folder
IMG_SIZE     = 224          # resize target (pixels)
BATCH_SIZE   = 32
NUM_WORKERS  = 4
SEED         = 42
SPLIT        = (0.70, 0.15, 0.15)   # train / val / test

random.seed(SEED)
np.random.seed(SEED)


# ─────────────────────────────────────────────
# 1. EXPLORE DATASET STRUCTURE
# ─────────────────────────────────────────────
def run_eda(root: str) -> dict:
    """
    Walks the dataset root and prints key statistics.
    Assumes folder-per-class layout:
        root/
          chromosome_1/ img001.png ...
          chromosome_2/ ...
          X/  ...
          Y/  ...
    """
    root = Path(root)
    class_counts = {}
    img_sizes    = []
    extensions   = Counter()

    print(f"\n{'='*55}")
    print(f"  DATASET EDA  ·  Root: {root}")
    print(f"{'='*55}")

    for cls_dir in sorted(root.iterdir()):
        if not cls_dir.is_dir():
            continue
        files = [f for f in cls_dir.iterdir() if f.suffix.lower() in
                 {'.png', '.jpg', '.jpeg', '.bmp', '.tiff'}]
        class_counts[cls_dir.name] = len(files)
        extensions.update(f.suffix.lower() for f in files)

        # sample a few images to check size
        for f in files[:5]:
            img = cv2.imread(str(f))
            if img is not None:
                img_sizes.append(img.shape[:2])   # (H, W)

    total = sum(class_counts.values())
    print(f"\n  Total images  : {total:,}")
    print(f"  Total classes : {len(class_counts)}")
    print(f"  Extensions    : {dict(extensions)}")

    if img_sizes:
        hs, ws = zip(*img_sizes)
        print(f"  Image heights : min={min(hs)}  max={max(hs)}  mean={np.mean(hs):.0f}")
        print(f"  Image widths  : min={min(ws)}  max={max(ws)}  mean={np.mean(ws):.0f}")

    print(f"\n  {'Class':<20} {'Count':>7}  {'% of total':>10}")
    print(f"  {'-'*42}")
    for cls, cnt in sorted(class_counts.items()):
        bar = "█" * int(cnt / total * 40)
        print(f"  {cls:<20} {cnt:>7}  {cnt/total*100:>8.1f}%  {bar}")

    # Imbalance warning
    counts = list(class_counts.values())
    ratio  = max(counts) / (min(counts) + 1e-9)
    if ratio > 3:
        print(f"\n  ⚠  Class imbalance ratio = {ratio:.1f}x  → use weighted sampler or oversampling")
    else:
        print(f"\n  ✓  Class balance ratio = {ratio:.1f}x  (acceptable)")

    return class_counts


def plot_samples(root: str, n_per_class: int = 3):
    """Show sample images for each class in a grid."""
    root    = Path(root)
    classes = sorted([d for d in root.iterdir() if d.is_dir()])
    n_cls   = len(classes)

    fig, axes = plt.subplots(n_cls, n_per_class,
                             figsize=(n_per_class * 2.5, n_cls * 2.5))
    fig.suptitle("Sample images per chromosome class", fontsize=14)

    for r, cls_dir in enumerate(classes):
        files = list(cls_dir.glob("*"))[:n_per_class]
        for c, f in enumerate(files):
            img = cv2.imread(str(f), cv2.IMREAD_GRAYSCALE)
            ax  = axes[r][c] if n_cls > 1 else axes[c]
            ax.imshow(img, cmap="gray")
            ax.set_title(cls_dir.name, fontsize=8)
            ax.axis("off")

    plt.tight_layout()
    plt.savefig("eda_samples.png", dpi=120, bbox_inches="tight")
    plt.show()
    print("  Saved → eda_samples.png")


# ─────────────────────────────────────────────
# 2. TRAIN / VAL / TEST SPLIT
# ─────────────────────────────────────────────
def split_dataset(root: str,
                  output_root: str = "dataset_split",
                  split: tuple = SPLIT):
    """
    Copies images into output_root/train|val|test/<class>/ folders.
    Call this ONCE. Skip if already done.
    """
    output_root = Path(output_root)
    if output_root.exists():
        print(f"  Split already exists at '{output_root}' — skipping.")
        return str(output_root)

    root   = Path(root)
    tr, vl, te = split
    print(f"\n  Splitting dataset  train={tr:.0%}  val={vl:.0%}  test={te:.0%}")

    for cls_dir in sorted(root.iterdir()):
        if not cls_dir.is_dir():
            continue
        files = list(cls_dir.glob("*"))
        random.shuffle(files)

        n       = len(files)
        n_tr    = int(n * tr)
        n_vl    = int(n * vl)
        splits  = {"train": files[:n_tr],
                   "val":   files[n_tr:n_tr + n_vl],
                   "test":  files[n_tr + n_vl:]}

        for split_name, split_files in splits.items():
            dest = output_root / split_name / cls_dir.name
            dest.mkdir(parents=True, exist_ok=True)
            for f in split_files:
                shutil.copy(f, dest / f.name)

        print(f"    {cls_dir.name:<20}  train={len(splits['train'])}  "
              f"val={len(splits['val'])}  test={len(splits['test'])}")

    print(f"  ✓  Split saved to '{output_root}'")
    return str(output_root)


# ─────────────────────────────────────────────
# 3. AUGMENTATION PIPELINES
# ─────────────────────────────────────────────
def get_train_transform(img_size: int = IMG_SIZE) -> A.Compose:
    """
    Heavy augmentation for training.
    Chromosomes appear at ANY angle → rotation up to 180°.
    ElasticTransform simulates natural chromosome bending.
    """
    return A.Compose([
        A.Resize(img_size, img_size),
        # Spatial
        A.Rotate(limit=180, p=0.9),
        A.HorizontalFlip(p=0.5),
        A.VerticalFlip(p=0.5),
        A.ShiftScaleRotate(shift_limit=0.05, scale_limit=0.1,
                           rotate_limit=15, p=0.5),
        A.ElasticTransform(alpha=1, sigma=50, alpha_affine=50, p=0.3),
        # Photometric — mimic stain variation
        A.RandomBrightnessContrast(brightness_limit=0.2,
                                   contrast_limit=0.2, p=0.5),
        A.GaussNoise(var_limit=(10, 50), p=0.3),
        A.GaussianBlur(blur_limit=(3, 5), p=0.2),
        A.CLAHE(clip_limit=4.0, p=0.3),   # contrast-limited adaptive histogram eq.
        # Normalize to ImageNet stats (pretrained models expect this)
        A.Normalize(mean=[0.485, 0.456, 0.406],
                    std=[0.229, 0.224, 0.225]),
        ToTensorV2(),
    ])


def get_val_transform(img_size: int = IMG_SIZE) -> A.Compose:
    """Minimal transform for val/test — only resize + normalize."""
    return A.Compose([
        A.Resize(img_size, img_size),
        A.Normalize(mean=[0.485, 0.456, 0.406],
                    std=[0.229, 0.224, 0.225]),
        ToTensorV2(),
    ])


# ─────────────────────────────────────────────
# 4. DATASET CLASS
# ─────────────────────────────────────────────
class ChromosomeDataset(Dataset):
    """
    Folder-per-class dataset.
    Converts grayscale chromosome images to 3-channel
    (duplicates the channel) so pretrained RGB models work.
    """

    def __init__(self, root: str, transform=None):
        self.root      = Path(root)
        self.transform = transform
        self.classes   = sorted([d.name for d in self.root.iterdir()
                                 if d.is_dir()])
        self.class_to_idx = {c: i for i, c in enumerate(self.classes)}

        self.samples = []   # list of (path, label_idx)
        for cls in self.classes:
            cls_dir = self.root / cls
            for f in cls_dir.glob("*"):
                if f.suffix.lower() in {".png", ".jpg", ".jpeg", ".bmp"}:
                    self.samples.append((str(f), self.class_to_idx[cls]))

        print(f"  Dataset '{root}':  {len(self.samples)} images  "
              f"·  {len(self.classes)} classes")

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        path, label = self.samples[idx]

        # Read as grayscale, then convert to 3-channel
        img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
        if img is None:
            raise FileNotFoundError(f"Cannot read image: {path}")

        img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)   # (H, W, 3)

        if self.transform:
            img = self.transform(image=img)["image"]

        return img, label

    def get_class_weights(self) -> torch.Tensor:
        """
        Inverse-frequency weights for weighted random sampler.
        Fixes class imbalance automatically.
        """
        label_counts = Counter(lbl for _, lbl in self.samples)
        total        = len(self.samples)
        weights      = [total / label_counts[lbl] for _, lbl in self.samples]
        return torch.tensor(weights, dtype=torch.float)


# ─────────────────────────────────────────────
# 5. DATALOADERS
# ─────────────────────────────────────────────
def build_dataloaders(split_root: str,
                      img_size: int   = IMG_SIZE,
                      batch_size: int = BATCH_SIZE,
                      num_workers: int = NUM_WORKERS,
                      use_weighted_sampler: bool = True):
    """
    Returns dict of DataLoaders: {"train", "val", "test"}
    and the list of class names.
    """
    from torch.utils.data import WeightedRandomSampler

    datasets = {
        "train": ChromosomeDataset(f"{split_root}/train",
                                   transform=get_train_transform(img_size)),
        "val":   ChromosomeDataset(f"{split_root}/val",
                                   transform=get_val_transform(img_size)),
        "test":  ChromosomeDataset(f"{split_root}/test",
                                   transform=get_val_transform(img_size)),
    }

    loaders = {}
    for split_name, ds in datasets.items():
        if split_name == "train" and use_weighted_sampler:
            weights = ds.get_class_weights()
            sampler = WeightedRandomSampler(weights, num_samples=len(weights),
                                            replacement=True)
            loaders[split_name] = DataLoader(ds, batch_size=batch_size,
                                              sampler=sampler,
                                              num_workers=num_workers,
                                              pin_memory=True)
        else:
            loaders[split_name] = DataLoader(ds, batch_size=batch_size,
                                              shuffle=False,
                                              num_workers=num_workers,
                                              pin_memory=True)

    class_names = datasets["train"].classes
    return loaders, class_names


# ─────────────────────────────────────────────
# 6. VISUALIZE AUGMENTATIONS
# ─────────────────────────────────────────────
def visualize_augmentations(image_path: str, n_versions: int = 8):
    """Show how augmentation transforms one image — run to sanity-check."""
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)

    transform = A.Compose([
        A.Resize(IMG_SIZE, IMG_SIZE),
        A.Rotate(limit=180, p=1.0),
        A.HorizontalFlip(p=0.5),
        A.ElasticTransform(alpha=1, sigma=50, alpha_affine=50, p=0.6),
        A.RandomBrightnessContrast(0.3, 0.3, p=0.8),
        A.GaussNoise(var_limit=(10, 60), p=0.5),
    ])

    fig, axes = plt.subplots(2, n_versions // 2, figsize=(16, 6))
    axes      = axes.flatten()
    axes[0].imshow(cv2.resize(img, (IMG_SIZE, IMG_SIZE)), cmap="gray")
    axes[0].set_title("Original", fontsize=9)
    axes[0].axis("off")

    for i in range(1, n_versions):
        aug = transform(image=img)["image"]
        axes[i].imshow(aug, cmap="gray")
        axes[i].set_title(f"Aug {i}", fontsize=9)
        axes[i].axis("off")

    plt.suptitle("Augmentation preview — chromosome images", fontsize=12)
    plt.tight_layout()
    plt.savefig("augmentation_preview.png", dpi=120)
    plt.show()
    print("  Saved → augmentation_preview.png")


# ─────────────────────────────────────────────
# MAIN — run EDA
# ─────────────────────────────────────────────
if __name__ == "__main__":
    # Step 1: EDA
    class_counts = run_eda(DATASET_ROOT)

    # Step 2: Sample images
    # plot_samples(DATASET_ROOT)              # uncomment to view

    # Step 3: Split
    split_root = split_dataset(DATASET_ROOT, output_root="dataset_split")

    # Step 4: Build loaders
    loaders, class_names = build_dataloaders(split_root)
    print(f"\n  Class names: {class_names}")
    print(f"  Train batches: {len(loaders['train'])}")
    print(f"  Val   batches: {len(loaders['val'])}")
    print(f"  Test  batches: {len(loaders['test'])}")

    # Step 5: Sanity-check one batch
    images, labels = next(iter(loaders["train"]))
    print(f"\n  Batch shape  : {images.shape}")   # (B, 3, 224, 224)
    print(f"  Label sample : {labels[:8].tolist()}")
    print(f"\n  ✓  Phase 1 & 2 complete. Proceed to 02_models.py")
