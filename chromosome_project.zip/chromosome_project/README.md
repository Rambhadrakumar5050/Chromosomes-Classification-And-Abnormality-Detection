# Chromosome Karyotyping — Deep Learning Project
## Summer Internship | AI-based Chromosome Classification

### Project Overview
Multi-model comparison for automated chromosome classification using deep learning.
Models compared: ResNet50, EfficientNet-B3, VGG16, VarifocalNet, Ensemble.
Based on: *"Fully Automatic Karyotyping via Deep Convolutional Neural Networks"* (Wang et al.)

---

### Project Structure
```
chromosome_project/
├── 01_eda_preprocessing.py   # Phase 1&2: EDA, augmentation, dataset class
├── 02_models.py              # Phase 3:   All 5 model definitions
├── 03_train.py               # Phase 3:   Training loop with early stopping
├── 04_evaluate.py            # Phase 4:   Metrics, confusion matrix, Grad-CAM
├── 05_app.py                 # Phase 5:   Streamlit deployment app
├── requirements.txt          # Python dependencies
├── checkpoints/              # Saved model weights (auto-created)
├── dataset_split/            # Train/val/test folders (auto-created)
└── README.md
```

---

### Setup
```bash
# 1. Create virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set your dataset path in 01_eda_preprocessing.py
#    DATASET_ROOT = "path/to/single_chromosomes_object"
```

---

### Run Order

#### Step 1 — EDA & Preprocessing
```bash
python 01_eda_preprocessing.py
```
Outputs: `eda_samples.png`, `augmentation_preview.png`, `dataset_split/` folder

#### Step 2 — Train all models (takes several hours on GPU)
```bash
# Train all models sequentially
python 03_train.py --model all --epochs 60

# Or train one at a time
python 03_train.py --model resnet50     --epochs 60
python 03_train.py --model efficientnet --epochs 60
python 03_train.py --model vgg16        --epochs 60
python 03_train.py --model varifocalnet --epochs 60
```
Outputs: `checkpoints/*.pth`, `history_*.png`, `history_*.json`

#### Step 3 — Evaluate & Compare
```bash
python 04_evaluate.py
```
Outputs: `cm_*.png` (confusion matrices), `gradcam_*.png`, 
         `model_comparison.csv`, `comparison_bar.png`, `evaluation_results.json`

#### Step 4 — Run Web App
```bash
streamlit run 05_app.py
```
Opens browser at http://localhost:8501

---

### Key Design Decisions

| Decision | Choice | Reason |
|---|---|---|
| Input channels | 3-channel (duplicated grayscale) | Pretrained models expect RGB |
| Augmentation | Rotation ±180° + ElasticTransform | Chromosomes at any angle; natural bending |
| Loss function | Label-smoothing CE (ε=0.1) | Prevents overconfidence on similar classes |
| Optimizer | AdamW + CosineAnnealingLR | Best convergence for fine-tuning |
| Training strategy | 2-phase (warmup → full finetune) | Prevents destroying pretrained weights |
| Class imbalance | WeightedRandomSampler | Balances rare chromosome classes |

---

### Models Summary

| Model | Parameters | Key Feature |
|---|---|---|
| ResNet50 | ~25M | Base paper baseline (ChrNet4 comparison) |
| EfficientNet-B3 | ~12M | Best acc/param ratio; recommended primary |
| VGG16-BN | ~138M | Classic deep CNN baseline |
| VarifocalNet | ~15M | Dual-scale (global shape + local banding) |
| Ensemble | — | Soft-vote of top 3 models |

---

### Research Paper Notes
Your novelty over the base paper:
1. Multi-model ablation study (4 architectures + ensemble)
2. VarifocalNet dual-branch adapted for chromosome texture
3. Grad-CAM explainability for clinical interpretability
4. Label-smoothing for morphologically similar chromosome classes
5. Systematic comparison on same dataset/splits

Target journals: IEEE Access, Biomedical Signal Processing and Control,
                 Computers in Biology and Medicine

---

### Expected Results (typical ranges)
| Model | Val Accuracy |
|---|---|
| ResNet50 | 91–94% |
| EfficientNet-B3 | 93–96% |
| VGG16 | 90–93% |
| VarifocalNet | 92–95% |
| Ensemble | 94–97% |

Actual results depend on your dataset size and quality.
