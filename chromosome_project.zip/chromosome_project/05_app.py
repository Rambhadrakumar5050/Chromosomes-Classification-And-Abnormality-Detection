"""
Phase 5 — Streamlit Deployment App
Upload a chromosome image → get classification + Grad-CAM heatmap.
Shows model comparison bar chart from saved results.

Run:
    streamlit run 05_app.py
"""

import streamlit as st
import torch
import torch.nn.functional as F
import numpy as np
import cv2
import json
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from pathlib import Path
from PIL import Image
import io

from _02_models import get_model
from _04_evaluate import GradCAM, get_gradcam_layer
from _01_eda_preprocessing import get_val_transform

# ── Page config ──────────────────────────────
st.set_page_config(
    page_title="Chromosome Classifier",
    page_icon="🔬",
    layout="wide",
)

# ── Constants ─────────────────────────────────
CKPT_DIR    = "checkpoints"
NUM_CLASSES = 24
IMG_SIZE    = 224
CLASS_NAMES = (
    [str(i) for i in range(1, 23)] + ["X", "Y"]
)   # update with your actual class names from training

CHROMOSOME_INFO = {
    "1":  "Largest chromosome. Contains ~8% of the human genome.",
    "21": "Trisomy 21 causes Down syndrome.",
    "X":  "Sex chromosome. Normal females have two X chromosomes.",
    "Y":  "Sex chromosome. Determines male sex. Contains SRY gene.",
}

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# ── Cache model loading ───────────────────────
@st.cache_resource
def load_model(model_name: str):
    ckpt_path = Path(CKPT_DIR) / f"{model_name}_best.pth"
    if not ckpt_path.exists():
        return None
    model = get_model(model_name, NUM_CLASSES, pretrained=False)
    state = torch.load(ckpt_path, map_location=DEVICE)
    model.load_state_dict(state["model_state_dict"])
    model.to(DEVICE)
    model.eval()
    return model


@st.cache_data
def load_results():
    path = Path("evaluation_results.json")
    if path.exists():
        with open(path) as f:
            return json.load(f)
    return {}


def preprocess_image(pil_image: Image.Image) -> torch.Tensor:
    """Convert PIL image → normalized tensor."""
    img  = np.array(pil_image.convert("L"))   # grayscale
    img  = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    tfm  = get_val_transform(IMG_SIZE)
    tens = tfm(image=img)["image"]
    return tens.unsqueeze(0)   # (1, 3, H, W)


def generate_gradcam(model, model_name: str,
                     img_tensor: torch.Tensor,
                     class_idx: int) -> np.ndarray:
    target_layer = get_gradcam_layer(model, model_name)
    if target_layer is None:
        return None
    gc  = GradCAM(model, target_layer)
    cam = gc(img_tensor.to(DEVICE), class_idx=class_idx)
    gc.remove()
    return cam


def overlay_heatmap(orig_pil: Image.Image,
                    cam: np.ndarray) -> Image.Image:
    orig_np = np.array(orig_pil.resize((IMG_SIZE, IMG_SIZE)).convert("RGB"))
    cam_big = cv2.resize(cam, (IMG_SIZE, IMG_SIZE))
    heatmap = cv2.applyColorMap((cam_big * 255).astype(np.uint8),
                                cv2.COLORMAP_JET)
    heatmap = cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB)
    overlay = cv2.addWeighted(orig_np, 0.55, heatmap, 0.45, 0)
    return Image.fromarray(overlay)


# ─────────────────────────────────────────────
# APP
# ─────────────────────────────────────────────
def main():
    st.markdown("# 🔬 Chromosome Classification System")
    st.markdown(
        "Upload a microscopic chromosome image to get AI-based classification "
        "with Grad-CAM explainability."
    )

    # ── Sidebar ───────────────────────────────
    st.sidebar.markdown("## ⚙ Settings")
    available_models = [n for n in ["resnet50", "efficientnet", "vgg16", "varifocalnet"]
                        if (Path(CKPT_DIR) / f"{n}_best.pth").exists()]

    if not available_models:
        st.error("No trained model checkpoints found in 'checkpoints/'. "
                 "Please run 03_train.py first.")
        return

    selected_model = st.sidebar.selectbox(
        "Select model", available_models,
        index=available_models.index("efficientnet")
        if "efficientnet" in available_models else 0
    )
    show_gradcam = st.sidebar.checkbox("Show Grad-CAM heatmap", value=True)
    top_k        = st.sidebar.slider("Show top-K predictions", 3, 10, 5)

    st.sidebar.markdown("---")
    st.sidebar.markdown("**Research Project**  \nSummer Internship 2024  \n"
                        "Chromosome Karyotyping using Deep Learning")

    # ── Load model ────────────────────────────
    with st.spinner(f"Loading {selected_model}..."):
        model = load_model(selected_model)

    if model is None:
        st.error(f"Could not load model: {selected_model}")
        return

    # ── Main layout: two columns ──────────────
    col1, col2 = st.columns([1, 1])

    with col1:
        st.markdown("### 📁 Upload Chromosome Image")
        uploaded = st.file_uploader(
            "Supported formats: PNG, JPG, JPEG, BMP",
            type=["png", "jpg", "jpeg", "bmp"],
        )

        if uploaded:
            pil_img = Image.open(uploaded)
            st.image(pil_img, caption="Uploaded image", use_column_width=True)

    with col2:
        if uploaded:
            st.markdown("### 🧬 Classification Result")

            img_tensor = preprocess_image(pil_img)

            with torch.no_grad():
                logits  = model(img_tensor.to(DEVICE))
                probs   = F.softmax(logits, dim=1).cpu().numpy()[0]

            pred_idx  = probs.argmax()
            pred_cls  = CLASS_NAMES[pred_idx]
            pred_conf = probs[pred_idx]

            # Result card
            status_color = "#0F6E56" if pred_conf > 0.8 else "#854F0B"
            st.markdown(
                f"""
                <div style="background:#f8f8f8;padding:16px;border-radius:10px;
                            border-left:4px solid {status_color}">
                  <h2 style="margin:0;color:{status_color}">
                    Chromosome {pred_cls}
                  </h2>
                  <p style="margin:6px 0 0;color:#555;font-size:14px">
                    Confidence: <b>{pred_conf:.2%}</b> · 
                    Model: <b>{selected_model}</b>
                  </p>
                </div>
                """,
                unsafe_allow_html=True,
            )

            # Chromosome info
            if pred_cls in CHROMOSOME_INFO:
                st.info(f"ℹ️ {CHROMOSOME_INFO[pred_cls]}")

            # Top-K bar chart
            st.markdown(f"#### Top-{top_k} predictions")
            top_idx  = np.argsort(probs)[::-1][:top_k]
            top_cls  = [CLASS_NAMES[i] for i in top_idx]
            top_conf = [probs[i] for i in top_idx]

            fig, ax = plt.subplots(figsize=(6, 3))
            colors  = ["#185FA5" if i == 0 else "#B5D4F4"
                       for i in range(top_k)]
            ax.barh(top_cls[::-1], top_conf[::-1],
                    color=colors[::-1], edgecolor="white")
            ax.set_xlim(0, 1)
            ax.set_xlabel("Probability")
            ax.spines[["top", "right"]].set_visible(False)
            plt.tight_layout()
            st.pyplot(fig)
            plt.close()

    # ── Grad-CAM ──────────────────────────────
    if uploaded and show_gradcam:
        st.markdown("---")
        st.markdown("### 🔥 Grad-CAM — Attention Heatmap")
        st.markdown(
            "The heatmap shows which region of the chromosome the model "
            "focused on to make its prediction."
        )

        cam = generate_gradcam(model, selected_model, img_tensor, int(pred_idx))
        if cam is not None:
            overlay = overlay_heatmap(pil_img, cam)
            gc1, gc2, gc3 = st.columns(3)
            with gc1:
                st.image(pil_img.resize((IMG_SIZE, IMG_SIZE)),
                         caption="Original", use_column_width=True)
            with gc2:
                fig_cam, ax_cam = plt.subplots(figsize=(3, 3))
                ax_cam.imshow(cam, cmap="jet")
                ax_cam.axis("off")
                st.pyplot(fig_cam)
                plt.close()
                st.caption("Grad-CAM heatmap")
            with gc3:
                st.image(overlay, caption="Overlay",
                         use_column_width=True)

    # ── Model comparison section ───────────────
    st.markdown("---")
    st.markdown("### 📊 Model Comparison (Test Set Results)")

    results = load_results()
    if results:
        df = pd.DataFrame([
            {
                "Model":       name,
                "Accuracy":    float(res.get("accuracy", 0)),
                "F1 (macro)":  float(res.get("f1_macro", 0)),
                "F1 (wtd)":    float(res.get("f1_weighted", 0)),
                "ROC-AUC":     float(res.get("roc_auc", 0)),
            }
            for name, res in results.items()
        ])
        df = df.set_index("Model")

        # Style: highlight best in each column
        st.dataframe(
            df.style.highlight_max(axis=0, color="#C0DD97")
                    .format("{:.4f}"),
            use_container_width=True,
        )

        # Accuracy bar chart
        fig, ax = plt.subplots(figsize=(8, 4))
        colors  = ["#185FA5", "#3B6D11", "#854F0B", "#993556", "#533b97"]
        bars    = ax.bar(df.index, df["Accuracy"],
                         color=colors[:len(df)], edgecolor="white",
                         linewidth=0.5)
        for bar in bars:
            ax.text(bar.get_x() + bar.get_width() / 2,
                    bar.get_height() + 0.003,
                    f"{bar.get_height():.4f}",
                    ha="center", va="bottom", fontsize=9)
        ax.set_ylim(df["Accuracy"].min() - 0.05, 1.01)
        ax.set_ylabel("Test Accuracy")
        ax.set_title("Accuracy Comparison Across All Models")
        ax.grid(axis="y", alpha=0.3)
        ax.spines[["top", "right"]].set_visible(False)
        plt.tight_layout()
        st.pyplot(fig)
        plt.close()
    else:
        st.info("Run 04_evaluate.py to generate comparison results.")


if __name__ == "__main__":
    main()
