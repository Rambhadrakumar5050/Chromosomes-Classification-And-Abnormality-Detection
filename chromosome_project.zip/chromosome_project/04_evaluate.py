"""
Phase 4 — Evaluation, Grad-CAM & Model Comparison
Run this after all models are trained. Generates:
  - Per-model: accuracy, F1, precision, recall, ROC-AUC
  - Confusion matrices (one per model)
  - Grad-CAM heatmaps (which part of chromosome was attended to)
  - Final comparison table (the core of your research paper's results section)
  - Ensemble evaluation

Usage:
    python 04_evaluate.py
"""

import os
import json
import torch
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import seaborn as sns
import cv2
from pathlib import Path
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    roc_auc_score,
    f1_score,
    accuracy_score,
)
from sklearn.preprocessing import label_binarize
import pandas as pd

from _01_eda_preprocessing import build_dataloaders, get_val_transform, ChromosomeDataset
from _02_models import get_model, build_ensemble

# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────
SPLIT_ROOT   = "dataset_split"
NUM_CLASSES  = 24
CKPT_DIR     = "checkpoints"
BATCH_SIZE   = 32
NUM_WORKERS  = 4
IMG_SIZE     = 224

MODEL_NAMES  = ["resnet50", "efficientnet", "vgg16", "varifocalnet"]


# ─────────────────────────────────────────────
# LOAD MODEL FROM CHECKPOINT
# ─────────────────────────────────────────────
def load_checkpoint(model_name: str, num_classes: int,
                    device: torch.device) -> nn.Module:
    model = get_model(model_name, num_classes, pretrained=False)
    path  = Path(CKPT_DIR) / f"{model_name}_best.pth"
    state = torch.load(path, map_location=device)
    model.load_state_dict(state["model_state_dict"])
    model.to(device)
    model.eval()
    print(f"  Loaded {model_name} from {path}  "
          f"(best val_acc={state['val_acc']:.4f})")
    return model


# ─────────────────────────────────────────────
# INFERENCE — get all predictions
# ─────────────────────────────────────────────
@torch.no_grad()
def predict_all(model, loader, device, return_probs: bool = True):
    """Returns (y_true, y_pred, y_probs) numpy arrays."""
    all_labels, all_preds, all_probs = [], [], []

    for images, labels in loader:
        images  = images.to(device)
        logits  = model(images)
        probs   = torch.softmax(logits, dim=1).cpu().numpy()
        preds   = probs.argmax(axis=1)

        all_labels.append(labels.numpy())
        all_preds.append(preds)
        all_probs.append(probs)

    return (np.concatenate(all_labels),
            np.concatenate(all_preds),
            np.concatenate(all_probs))


# ─────────────────────────────────────────────
# METRICS
# ─────────────────────────────────────────────
def compute_metrics(y_true, y_pred, y_probs, class_names):
    """Returns a dict of all metrics for the paper's results table."""
    acc     = accuracy_score(y_true, y_pred)
    f1_mac  = f1_score(y_true, y_pred, average="macro")
    f1_wei  = f1_score(y_true, y_pred, average="weighted")
    report  = classification_report(y_true, y_pred,
                                    target_names=class_names,
                                    output_dict=True)

    # ROC-AUC (one-vs-rest)
    y_bin = label_binarize(y_true, classes=list(range(len(class_names))))
    try:
        roc_auc = roc_auc_score(y_bin, y_probs, multi_class="ovr",
                                 average="macro")
    except ValueError:
        roc_auc = float("nan")

    return {
        "accuracy":      acc,
        "f1_macro":      f1_mac,
        "f1_weighted":   f1_wei,
        "roc_auc":       roc_auc,
        "report":        report,
    }


def print_metrics(model_name: str, metrics: dict):
    print(f"\n  ┌─ {model_name.upper()} ─────────────────────────")
    print(f"  │  Accuracy   : {metrics['accuracy']:.4f}")
    print(f"  │  F1 (macro) : {metrics['f1_macro']:.4f}")
    print(f"  │  F1 (wtd)   : {metrics['f1_weighted']:.4f}")
    print(f"  │  ROC-AUC    : {metrics['roc_auc']:.4f}")
    print(f"  └────────────────────────────────────────")


# ─────────────────────────────────────────────
# CONFUSION MATRIX
# ─────────────────────────────────────────────
def plot_confusion_matrix(y_true, y_pred, class_names, model_name):
    cm  = confusion_matrix(y_true, y_pred)
    fig, ax = plt.subplots(figsize=(14, 12))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=class_names,
                yticklabels=class_names,
                linewidths=0.3, ax=ax, cbar=False)
    ax.set_xlabel("Predicted label", fontsize=11)
    ax.set_ylabel("True label",      fontsize=11)
    ax.set_title(f"Confusion Matrix — {model_name}\n"
                 f"Accuracy = {accuracy_score(y_true, y_pred):.4f}",
                 fontsize=13)
    plt.tight_layout()
    fname = f"cm_{model_name}.png"
    plt.savefig(fname, dpi=120)
    plt.close()
    print(f"  Saved → {fname}")


# ─────────────────────────────────────────────
# GRAD-CAM
# ─────────────────────────────────────────────
class GradCAM:
    """
    Generates Grad-CAM heatmaps showing WHICH PART of the chromosome
    the model attended to for its prediction.
    Essential for research paper — reviewers love this.
    """

    def __init__(self, model: nn.Module, target_layer: nn.Module):
        self.model   = model
        self.grads   = None
        self.activs  = None
        self._hooks  = []

        self._hooks.append(
            target_layer.register_forward_hook(self._save_activs)
        )
        self._hooks.append(
            target_layer.register_full_backward_hook(self._save_grads)
        )

    def _save_activs(self, module, input, output):
        self.activs = output.detach()

    def _save_grads(self, module, grad_in, grad_out):
        self.grads = grad_out[0].detach()

    def __call__(self, image_tensor: torch.Tensor,
                 class_idx: int = None) -> np.ndarray:
        """
        Args:
            image_tensor: (1, 3, H, W)  on the same device as model
            class_idx: target class (None → predicted class)
        Returns:
            heatmap: (H, W) numpy array in [0, 1]
        """
        self.model.eval()
        logits = self.model(image_tensor)

        if class_idx is None:
            class_idx = logits.argmax(dim=1).item()

        self.model.zero_grad()
        logits[0, class_idx].backward()

        # Global average pool gradients over spatial dims
        weights = self.grads.mean(dim=(2, 3), keepdim=True)  # (1, C, 1, 1)
        cam     = (weights * self.activs).sum(dim=1, keepdim=True)  # (1, 1, h, w)
        cam     = torch.relu(cam)
        cam     = cam.squeeze().cpu().numpy()

        # Normalize to [0, 1]
        if cam.max() > 0:
            cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
        return cam

    def remove(self):
        for h in self._hooks:
            h.remove()


def get_gradcam_layer(model: nn.Module, model_name: str) -> nn.Module:
    """Returns the last convolutional layer for each model architecture."""
    targets = {
        "resnet50":     model.layer4[-1],       # last ResNet block
        "efficientnet": model.features[-1],     # last MBConv block
        "vgg16":        model.features[-1],     # last conv layer
        "varifocalnet": model.stem[-1],         # last stem layer
    }
    return targets.get(model_name)


def visualize_gradcam(model, model_name, sample_images, class_names,
                      device, n_samples: int = 8):
    """
    Generate Grad-CAM overlays on sample chromosome images.
    Saves a grid showing original + heatmap + overlay.
    """
    target_layer = get_gradcam_layer(model, model_name)
    if target_layer is None:
        print(f"  Grad-CAM: no target layer configured for {model_name}")
        return

    gradcam = GradCAM(model, target_layer)
    model.train(False)

    fig, axes = plt.subplots(n_samples, 3,
                              figsize=(9, n_samples * 2.5))
    fig.suptitle(f"Grad-CAM — {model_name}", fontsize=13)

    norm_mean = np.array([0.485, 0.456, 0.406])
    norm_std  = np.array([0.229, 0.224, 0.225])

    for i, (img_tensor, true_label) in enumerate(sample_images[:n_samples]):
        inp     = img_tensor.unsqueeze(0).to(device)
        cam_map = gradcam(inp)

        logits   = model(inp)
        pred_cls = logits.argmax(dim=1).item()
        conf     = torch.softmax(logits, dim=1)[0, pred_cls].item()

        # De-normalize for display
        img_np  = img_tensor.permute(1, 2, 0).numpy()
        img_np  = (img_np * norm_std + norm_mean).clip(0, 1)
        img_rgb = (img_np * 255).astype(np.uint8)

        # Resize CAM to image size
        h, w    = img_rgb.shape[:2]
        cam_big = cv2.resize(cam_map, (w, h))
        heatmap = cv2.applyColorMap((cam_big * 255).astype(np.uint8),
                                    cv2.COLORMAP_JET)
        heatmap = cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB)
        overlay = cv2.addWeighted(img_rgb, 0.55, heatmap, 0.45, 0)

        color   = "green" if pred_cls == true_label else "red"
        title   = (f"True: {class_names[true_label]}\n"
                   f"Pred: {class_names[pred_cls]} ({conf:.2%})")

        ax_orig, ax_cam, ax_over = axes[i]
        ax_orig.imshow(img_rgb, cmap="gray")
        ax_orig.set_title("Original", fontsize=8)
        ax_orig.axis("off")

        ax_cam.imshow(cam_big, cmap="jet")
        ax_cam.set_title("Grad-CAM", fontsize=8)
        ax_cam.axis("off")

        ax_over.imshow(overlay)
        ax_over.set_title(title, fontsize=7, color=color)
        ax_over.axis("off")

    gradcam.remove()
    plt.tight_layout()
    fname = f"gradcam_{model_name}.png"
    plt.savefig(fname, dpi=130)
    plt.close()
    print(f"  Saved → {fname}")


# ─────────────────────────────────────────────
# MODEL COMPARISON TABLE
# ─────────────────────────────────────────────
def build_comparison_table(all_results: dict,
                            class_names: list) -> pd.DataFrame:
    """
    Builds the comparison table for your research paper's results section.
    Rows = models, Columns = metrics.
    """
    rows = []
    for name, res in all_results.items():
        rows.append({
            "Model":       name,
            "Accuracy":    f"{res['accuracy']:.4f}",
            "F1 (macro)":  f"{res['f1_macro']:.4f}",
            "F1 (wtd)":    f"{res['f1_weighted']:.4f}",
            "ROC-AUC":     f"{res['roc_auc']:.4f}",
        })

    df = pd.DataFrame(rows).set_index("Model")
    print(f"\n  {'='*55}")
    print(f"  MODEL COMPARISON TABLE (Test Set)")
    print(f"  {'='*55}")
    print(df.to_string())
    df.to_csv("model_comparison.csv")
    print(f"\n  Saved → model_comparison.csv")
    return df


def plot_comparison_bar(all_results: dict):
    """Bar chart comparing accuracy across all models."""
    names  = list(all_results.keys())
    accs   = [all_results[n]["accuracy"] for n in names]
    colors = ["#185FA5", "#3B6D11", "#854F0B", "#993556", "#533b97"]

    fig, ax = plt.subplots(figsize=(9, 5))
    bars    = ax.bar(names, accs, color=colors[:len(names)],
                     edgecolor="white", linewidth=0.5)

    for bar, acc in zip(bars, accs):
        ax.text(bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 0.002,
                f"{acc:.4f}", ha="center", va="bottom", fontsize=10)

    ax.set_ylim(min(accs) - 0.05, 1.01)
    ax.set_ylabel("Test Accuracy")
    ax.set_title("Model Comparison — Chromosome Classification (Test Set)")
    ax.grid(axis="y", alpha=0.3, linewidth=0.5)
    ax.spines[["top", "right"]].set_visible(False)

    plt.tight_layout()
    plt.savefig("comparison_bar.png", dpi=130)
    plt.close()
    print(f"  Saved → comparison_bar.png")


# ─────────────────────────────────────────────
# MAIN EVALUATION RUNNER
# ─────────────────────────────────────────────
def run_full_evaluation():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"  Device: {device}")

    loaders, class_names = build_dataloaders(
        SPLIT_ROOT, img_size=IMG_SIZE,
        batch_size=BATCH_SIZE, num_workers=NUM_WORKERS,
    )
    test_loader = loaders["test"]

    all_results = {}

    # ── Evaluate each individual model ────────
    for model_name in MODEL_NAMES:
        print(f"\n  Evaluating: {model_name.upper()}")
        ckpt_path = Path(CKPT_DIR) / f"{model_name}_best.pth"
        if not ckpt_path.exists():
            print(f"  ⚠  Checkpoint not found: {ckpt_path} — skipping")
            continue

        model = load_checkpoint(model_name, NUM_CLASSES, device)

        y_true, y_pred, y_probs = predict_all(model, test_loader, device)
        metrics = compute_metrics(y_true, y_pred, y_probs, class_names)
        print_metrics(model_name, metrics)

        plot_confusion_matrix(y_true, y_pred, class_names, model_name)

        # Grad-CAM on a few test samples
        test_ds      = ChromosomeDataset(f"{SPLIT_ROOT}/test",
                                         transform=get_val_transform(IMG_SIZE))
        sample_items = [test_ds[i] for i in range(16)]   # first 16 samples
        visualize_gradcam(model, model_name, sample_items,
                          class_names, device, n_samples=8)

        all_results[model_name] = metrics

    # ── Ensemble evaluation ───────────────────
    checkpoints = {n: str(Path(CKPT_DIR) / f"{n}_best.pth")
                   for n in MODEL_NAMES
                   if (Path(CKPT_DIR) / f"{n}_best.pth").exists()}

    if len(checkpoints) >= 2:
        print(f"\n  Evaluating: ENSEMBLE ({list(checkpoints.keys())})")
        ensemble = build_ensemble(checkpoints, NUM_CLASSES, device)

        # Ensemble predict
        all_labels, all_probs = [], []
        for images, labels in test_loader:
            probs = ensemble(images.to(device)).detach().cpu().numpy()
            all_labels.append(labels.numpy())
            all_probs.append(probs)

        y_true = np.concatenate(all_labels)
        y_probs = np.concatenate(all_probs)
        y_pred  = y_probs.argmax(axis=1)

        metrics = compute_metrics(y_true, y_pred, y_probs, class_names)
        print_metrics("Ensemble", metrics)
        plot_confusion_matrix(y_true, y_pred, class_names, "ensemble")
        all_results["ensemble"] = metrics

    # ── Comparison table ──────────────────────
    df = build_comparison_table(all_results, class_names)
    plot_comparison_bar(all_results)

    # Save full results
    save_results = {
        name: {k: v for k, v in res.items() if k != "report"}
        for name, res in all_results.items()
    }
    with open("evaluation_results.json", "w") as f:
        json.dump(save_results, f, indent=2, default=float)

    print("\n  ✓  Evaluation complete. Proceed to 05_app.py for deployment.")
    return all_results


if __name__ == "__main__":
    run_full_evaluation()
