"""
Phase 3 — Model Definitions
All 5 models in one file. Each function returns a ready-to-train model.
Models: ResNet50, EfficientNet-B3, VGG16, VarifocalNet, Ensemble
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models


# ─────────────────────────────────────────────────────────────
# HELPER — freeze / unfreeze backbone layers
# ─────────────────────────────────────────────────────────────
def freeze_backbone(model: nn.Module, unfreeze_last_n: int = 2):
    """
    Freeze all backbone parameters, then unfreeze the last N layers.
    Strategy: train only head for 5 epochs, then unfreeze & fine-tune.
    """
    for param in model.parameters():
        param.requires_grad = False

    # Unfreeze the last N children (usually the classifier / top blocks)
    children  = list(model.children())
    for child in children[-unfreeze_last_n:]:
        for param in child.parameters():
            param.requires_grad = True


def count_params(model: nn.Module) -> str:
    total     = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return f"Total={total/1e6:.2f}M  Trainable={trainable/1e6:.2f}M"


# ─────────────────────────────────────────────────────────────
# MODEL 1 — ResNet50  (base paper baseline)
# ─────────────────────────────────────────────────────────────
def get_resnet50(num_classes: int, pretrained: bool = True) -> nn.Module:
    """
    ResNet50 fine-tuned for chromosome classification.
    Used as the baseline in the base paper (ChrNet4 comparison).
    Input:  (B, 3, 224, 224)
    Output: (B, num_classes)
    """
    weights = models.ResNet50_Weights.IMAGENET1K_V2 if pretrained else None
    model   = models.resnet50(weights=weights)

    # Replace final FC layer
    in_features = model.fc.in_features          # 2048
    model.fc    = nn.Sequential(
        nn.Dropout(0.4),
        nn.Linear(in_features, 512),
        nn.ReLU(),
        nn.Dropout(0.3),
        nn.Linear(512, num_classes),
    )

    print(f"[ResNet50]       {count_params(model)}")
    return model


# ─────────────────────────────────────────────────────────────
# MODEL 2 — EfficientNet-B3  (recommended primary model)
# ─────────────────────────────────────────────────────────────
def get_efficientnet_b3(num_classes: int, pretrained: bool = True) -> nn.Module:
    """
    EfficientNet-B3: Best accuracy-per-parameter among CNNs.
    Consistently outperforms ResNet on medical imaging benchmarks.
    Input:  (B, 3, 300, 300) — internally handles 224 input too
    Output: (B, num_classes)
    """
    weights = models.EfficientNet_B3_Weights.IMAGENET1K_V1 if pretrained else None
    model   = models.efficientnet_b3(weights=weights)

    in_features = model.classifier[1].in_features   # 1536
    model.classifier = nn.Sequential(
        nn.Dropout(0.4),
        nn.Linear(in_features, 512),
        nn.SiLU(),               # same activation EfficientNet uses internally
        nn.Dropout(0.3),
        nn.Linear(512, num_classes),
    )

    print(f"[EfficientNet-B3] {count_params(model)}")
    return model


# ─────────────────────────────────────────────────────────────
# MODEL 3 — VGG16  (classic deep CNN comparison)
# ─────────────────────────────────────────────────────────────
def get_vgg16(num_classes: int, pretrained: bool = True) -> nn.Module:
    """
    VGG16 with batch normalization. Classic comparison model.
    Larger than EfficientNet but useful for the paper's ablation table.
    Input:  (B, 3, 224, 224)
    Output: (B, num_classes)
    """
    weights = models.VGG16_BN_Weights.IMAGENET1K_V1 if pretrained else None
    model   = models.vgg16_bn(weights=weights)

    in_features = model.classifier[6].in_features   # 4096
    model.classifier[6] = nn.Sequential(
        nn.Dropout(0.5),
        nn.Linear(in_features, 512),
        nn.ReLU(),
        nn.Dropout(0.4),
        nn.Linear(512, num_classes),
    )

    print(f"[VGG16-BN]       {count_params(model)}")
    return model


# ─────────────────────────────────────────────────────────────
# MODEL 4 — VarifocalNet-inspired (dual-scale attention)
# ─────────────────────────────────────────────────────────────
class ChannelAttention(nn.Module):
    """Squeeze-and-Excitation style channel attention."""
    def __init__(self, channels: int, reduction: int = 16):
        super().__init__()
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc   = nn.Sequential(
            nn.Linear(channels, channels // reduction, bias=False),
            nn.ReLU(),
            nn.Linear(channels // reduction, channels, bias=False),
            nn.Sigmoid(),
        )

    def forward(self, x):
        b, c, _, _ = x.shape
        s = self.pool(x).view(b, c)
        s = self.fc(s).view(b, c, 1, 1)
        return x * s


class GlobalBranch(nn.Module):
    """Captures whole-chromosome shape features (global context)."""
    def __init__(self, in_ch: int, out_ch: int):
        super().__init__()
        self.layers = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 7, padding=3, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d(8),
            nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(),
        )
        self.attn = ChannelAttention(out_ch)

    def forward(self, x):
        return self.attn(self.layers(x))


class LocalBranch(nn.Module):
    """Captures banding pattern detail (local texture)."""
    def __init__(self, in_ch: int, out_ch: int):
        super().__init__()
        self.layers = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(),
            nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(),
            nn.AdaptiveAvgPool2d(8),
        )

    def forward(self, x):
        return self.layers(x)


class VarifocalNet(nn.Module):
    """
    Dual-scale network inspired by Varifocal-Net (Qin et al. 2018).
    Two branches: global (chromosome shape) + local (banding detail).
    Features fused → shared classifier.
    Input:  (B, 3, 224, 224)
    Output: (B, num_classes)
    """

    def __init__(self, num_classes: int, pretrained_backbone: bool = True):
        super().__init__()

        # Shared stem — use ResNet18 feature extractor
        resnet = models.resnet18(
            weights=models.ResNet18_Weights.IMAGENET1K_V1 if pretrained_backbone else None
        )
        # Keep everything up to layer3 (output channels = 256)
        self.stem = nn.Sequential(
            resnet.conv1, resnet.bn1, resnet.relu, resnet.maxpool,
            resnet.layer1, resnet.layer2, resnet.layer3,
        )
        stem_ch = 256

        # Dual branches
        self.global_branch = GlobalBranch(stem_ch, 256)
        self.local_branch  = LocalBranch(stem_ch, 256)

        # Fusion + classifier
        fused_dim = 256 * 8 * 8 * 2   # both branches → flatten → cat

        # Project to a manageable size
        self.fusion = nn.Sequential(
            nn.AdaptiveAvgPool2d(4),   # reduce spatial before flatten
        )
        fused_dim = 256 * 4 * 4 * 2

        self.classifier = nn.Sequential(
            nn.Dropout(0.5),
            nn.Linear(fused_dim, 1024),
            nn.ReLU(),
            nn.Dropout(0.4),
            nn.Linear(1024, 256),
            nn.ReLU(),
            nn.Linear(256, num_classes),
        )

    def forward(self, x):
        feats = self.stem(x)                        # (B, 256, H', W')

        g = self.fusion(self.global_branch(feats))   # (B, 256, 4, 4)
        l = self.fusion(self.local_branch(feats))    # (B, 256, 4, 4)

        g = g.flatten(1)
        l = l.flatten(1)

        fused = torch.cat([g, l], dim=1)            # (B, 256*4*4*2)
        return self.classifier(fused)


def get_varifocalnet(num_classes: int, pretrained: bool = True) -> nn.Module:
    model = VarifocalNet(num_classes, pretrained_backbone=pretrained)
    print(f"[VarifocalNet]   {count_params(model)}")
    return model


# ─────────────────────────────────────────────────────────────
# MODEL 5 — Ensemble (soft voting of top models)
# ─────────────────────────────────────────────────────────────
class EnsembleModel(nn.Module):
    """
    Soft-vote ensemble: average probabilities from multiple models.
    Load each model's best checkpoint, then wrap in this class.

    Usage:
        models_list = [resnet, efficientnet, varifocalnet]
        ensemble    = EnsembleModel(models_list, weights=[0.3, 0.4, 0.3])
        logits      = ensemble(x)
    """

    def __init__(self, model_list: list, weights: list = None):
        super().__init__()
        self.models  = nn.ModuleList(model_list)
        # Learnable or fixed ensemble weights
        if weights is None:
            weights = [1.0 / len(model_list)] * len(model_list)
        self.weights = weights

        for m in self.models:
            for param in m.parameters():
                param.requires_grad = False    # frozen — ensemble doesn't train

    def forward(self, x):
        probs = []
        for model, w in zip(self.models, self.weights):
            logits = model(x)
            probs.append(F.softmax(logits, dim=1) * w)
        # Weighted average of probabilities
        avg_probs = torch.stack(probs).sum(dim=0)
        # Return log-probabilities (compatible with NLLLoss) OR raw probs
        return avg_probs    # caller can use .argmax(1) for predictions


def build_ensemble(checkpoints: dict,
                   num_classes: int,
                   device: torch.device,
                   weights: list = None) -> EnsembleModel:
    """
    Load saved checkpoints and assemble ensemble.

    checkpoints = {
        "resnet50":      "checkpoints/resnet50_best.pth",
        "efficientnet":  "checkpoints/efficientnet_best.pth",
        "varifocalnet":  "checkpoints/varifocalnet_best.pth",
    }
    """
    model_builders = {
        "resnet50":     lambda: get_resnet50(num_classes, pretrained=False),
        "efficientnet": lambda: get_efficientnet_b3(num_classes, pretrained=False),
        "vgg16":        lambda: get_vgg16(num_classes, pretrained=False),
        "varifocalnet": lambda: get_varifocalnet(num_classes, pretrained=False),
    }

    loaded = []
    for name, ckpt_path in checkpoints.items():
        model = model_builders[name]()
        state = torch.load(ckpt_path, map_location=device)
        model.load_state_dict(state["model_state_dict"])
        model.to(device)
        model.eval()
        loaded.append(model)
        print(f"  Loaded checkpoint: {name} from {ckpt_path}")

    ensemble = EnsembleModel(loaded, weights=weights)
    ensemble.to(device)
    return ensemble


# ─────────────────────────────────────────────────────────────
# FACTORY — get any model by name
# ─────────────────────────────────────────────────────────────
MODEL_REGISTRY = {
    "resnet50":     get_resnet50,
    "efficientnet": get_efficientnet_b3,
    "vgg16":        get_vgg16,
    "varifocalnet": get_varifocalnet,
}


def get_model(name: str, num_classes: int, pretrained: bool = True) -> nn.Module:
    if name not in MODEL_REGISTRY:
        raise ValueError(f"Unknown model '{name}'. Choose from {list(MODEL_REGISTRY)}")
    return MODEL_REGISTRY[name](num_classes, pretrained)


# ─────────────────────────────────────────────────────────────
# QUICK CHECK
# ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    NUM_CLASSES = 24    # 22 autosomes + X + Y

    print("\n  Model summary (24-class chromosome classification)\n")
    x = torch.randn(2, 3, 224, 224)

    for name in MODEL_REGISTRY:
        model  = get_model(name, NUM_CLASSES)
        out    = model(x)
        print(f"  → output shape: {out.shape}\n")

    print("  ✓  All models built successfully. Proceed to 03_train.py")
